# Repo for MRU-COMP4522-Assignments.

You will find two folders in this repository:

- CodeAndData Folder: the data and starting code for the assignment.
- Doc Folder: the document describing the assignment.

Please select the one of interest to you -or both- as applicable.
